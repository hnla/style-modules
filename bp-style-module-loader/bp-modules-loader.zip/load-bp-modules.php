<?php
/**
 * Load any available style modules located in a themes /buddpress/style-modules/ directory
 *
 *
 * @package   BuddyPress Style Modules Loader
 * @author    Hugo ( hnla )
 * @license   GPL-2.0+
 * @link      http://github.hnla/style-modules
 *
 * @buddypress-plugin
 * Plugin Name:       BuddyPress Modules Loader
 * Plugin URI:        https://github.com/hnla/style-modules
 * Description:       Provides stylesheet & JS enqueueing for located / installed BuddyPress style modules
 * Version:           1.0.0
 * Author:            Hugo Ashmore
 * Author URI:        https://github.com/hnla/style-modules
 * Text Domain:
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Domain Path:       /languages/
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) exit;

// Don't load if BP not active
if( function_exists('bp_loaded') ) :

class Load_Style_Modules {


	public function __construct() {

		$this->setup_globals();
		$this->setup_actions();
	}

	protected function setup_globals() {
		//Fetch dir paths - themes can use /buddypress or /community
		$this->theme_dir           = get_stylesheet_directory();
		$this->bp_folder_name      = $this->bp_folder_name();
		$this->theme_dir_bpfolder  = get_stylesheet_directory() . $this->bp_folder_name();
		$this->theme_dir_uri       = get_stylesheet_directory_uri() . $this->bp_folder_name;

		$this->the_modules    = $this->the_modules();
		$this->the_files      = $this->dir_files();
		$this->version        = '1.0.0';
	}

	protected function setup_actions() {
	add_action( 'bp_enqueue_scripts',  array( $this, 'enqueue_style_modules_sheets' ), 15 );
	add_action( 'bp_enqueue_scripts',  array( $this, 'enqueue_style_modules_js' ) );
	//add_action( 'init',   array( $this, 'test_dump' ) );
	}

	// Find the themes custom BP folder name
	public function bp_folder_name() {

		if( file_exists( $this->theme_dir . '/buddypress/') ) :
			$bp_folder = '/buddypress/';
		elseif( file_exists( $this->theme_dir . '/community/') ) :
			$bp_folder = '/community/';
		else:
			$bp_folder = false;
		endif;

		return $bp_folder;
	}

	// Locate Style Modules to load
	public function the_modules() {
		if( ! $this->bp_folder_name )
			return false;

		$modules = scandir( $this->theme_dir_bpfolder . '/style-modules/');

			$available_modules = array();
			foreach ( $modules as $key => $module ) {
				if( is_dir( $this->theme_dir_bpfolder . '/style-modules/' . $module ) && 'node_modules' != $module ) :
					$available_modules[$key] = $module;
				endif;
			}

			$all_modules = array();
			foreach($available_modules as $key => $module) {
				if(preg_match("/\b$module\b/i", $module ) ) {
					$all_modules[$key] = $module;
				}
			}

			return $all_modules;
	}

	public function dir_files() {
		if (!$the_modules = $this->the_modules )
			return false;

		foreach( $the_modules as $module ) {
			$location = $this->theme_dir_bpfolder . 'style-modules/' . $module . '/';

			$dhandle = opendir( $location);

			$files = array();
			while( false !== ( $fname = readdir($dhandle) ) ) {
				if (($fname != '.') && ($fname != '..') &&
						( $fname != basename($_SERVER['PHP_SELF']) ) && ($fname != '.svn') ) {
					$files[] = $fname;
				}
			}

			closedir($dhandle);

			foreach( $files as $file ) {
				$the_files[$file] = $file;
			}
		}

		return $the_files;
	}

	public function test_dump() {
	var_dump( $this->the_modules );
	}

	public function enqueue_style_modules_sheets() {
		$the_modules = $this->the_modules;
		$the_files = $this->the_files;

		foreach( $the_modules as  $module) {
			$handle = $module;

			$path_to_file = $this->theme_dir_uri  . 'style-modules/' . $module . '/';
			$file = $module . '.css';
			wp_enqueue_style( $handle, $path_to_file . $file, array('bp-legacy-css'), $this->version, 'screen' );
		}
	}

	public function enqueue_style_modules_js() {
		$the_modules = $this->the_modules;
		$the_files = $this->the_files;

		foreach( $the_modules as  $module) {
			if( !in_array( $module . '.js', $the_files ) )
				continue;
			$handle = $module;
			$path_to_file = $this->theme_dir_uri  . 'style-modules/' . $module . '/';
			$file = $module . '.js';
			wp_enqueue_script( $handle, $path_to_file . $file, array('jquery'), $this->version, true );
		}
	}

}

function set_the_styles_aloading() {
	new Load_Style_Modules();
}
add_action('bp_after_setup_theme', 'set_the_styles_aloading');

endif;

